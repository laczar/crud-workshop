const cors = {
    origins: ['*', 'localhost:3000'],
    headers: [
        'Origin',
        'X-Requested-With',
        'Content-Type',
        'Accept,X-Amz-Date',
        'Authorization',
        'X-Api-Key',
        'X-Amz-Security-Token'
    ],
    credentials: false,
    methods: true,
    headers: true

  };
  
  module.exports.defCors = cors;